package controller;

import java.util.Objects;
import open62Wrap.*;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import molding.MoldingMachine;
import molding.MoldingTrigger;

/**
 * This is the controller class for the MoldingMachine where the logic shall be
 * implemented also the OPCUA client/server implementations. The class extends
 * the the MoldingMachine model class, to implement the logic at each abstract
 * state in the model also wire up the connections between states as the logic
 * drives.
 * 
 * @author Michael Bishara
 */
public class MoldingMachineController extends MoldingMachine {
	ServerAPIBase serverAPI;
	SWIGTYPE_p_UA_Server server;
	UA_NodeId statusNodeID;
	static MoldingMachineController mMController;
	// static MoldingMachine_OPCUA mMachine_OPCUA;

	/**
	 * static initializing for the opcua java wrapper
	 */
	static {
		System.loadLibrary("opcua_java_api");
	}

	/**
	 * Extending for the Client API Base to implement the callback methods form the
	 * c libraries , enabling callback s from the c library to the java code.
	 */
	static class MoldingMachine_OPCUA extends ServerAPIBase {
		/**
		 * Receiving calls from the c library on monitored item(s) changed. can be
		 * further filtered by Node id. As a first step considering the monitored item
		 * value is int, but later could be changed to more generic variant.
		 * 
		 * @param nodeId the node id triggered the change
		 * @param value  the value of the node triggered the change
		 */
		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("iiiiii monitored_itemChanged::monitored_itemChanged() invoked." + value);
			if (value == MoldingTrigger.CLOSING.ordinal()) {
				System.out.println("The Robot is OUT lets close for the new mold");
				mMController.closeMold();
			}
		}

		@Override
		public void methods_callback(ServerAPIBase jAPIBase, UA_NodeId methodId, UA_NodeId objectId, String input,
				String output) {
			System.out.println(" iiiii Got a message responce " + input);

			jAPIBase.setMethodOutput("FROM JAVA");
			System.out.println(" iiiii Got a message responce " + jAPIBase.getData());
		}

	}

	/**
	 * This the MoldingMachine controller constructor
	 */
	public MoldingMachineController() {

		System.out.println("Start");
		serverAPI = new ServerAPIBase();

		server = serverAPI.createServer(4840, "localhost");
		
		UA_NodeId type = new UA_NodeId();
		type.setIdentifierType(UA_NodeIdType.UA_NODEIDTYPE_NUMERIC);
		
		UA_NodeId object  = serverAPI.addObject(server,20, "OPCUA Object");
		
		
	
		
		
		int accessRights = open62541.UA_ACCESSLEVELMASK_WRITE | open62541.UA_ACCESSLEVELMASK_READ;
		serverAPI.addVariableNode(server, object,30, "Hello Variable from Java", open62541.UA_TYPES_STRING, accessRights);
	
		statusNodeID = serverAPI.manuallyDefineIMM(server);
		serverAPI.addMonitoredItem(server, statusNodeID, new MoldingMachine_OPCUA());

		UA_LocalizedText locale = new UA_LocalizedText();
		locale.setLocale("en-US");
		locale.setText("A String");

		UA_Argument input = new UA_Argument();
		input.setDescription(locale);
		input.setName("MyInput");
		input.setDataType(serverAPI.getDataTypeNode(open62541.UA_TYPES_STRING));
		input.setValueRank(open62541.UA_VALUERANK_SCALAR);

		UA_Argument output = new UA_Argument();
		output.setDescription(locale);
		output.setName("MyOutput");
		output.setDataType(serverAPI.getDataTypeNode(open62541.UA_TYPES_STRING));
		output.setValueRank(open62541.UA_VALUERANK_SCALAR);

		UA_LocalizedText methodLocale = new UA_LocalizedText();
		methodLocale.setLocale("en-US");

		methodLocale.setText("SayHelloWorld");

		UA_MethodAttributes methodAttr = new UA_MethodAttributes();
		methodAttr.setDescription(methodLocale);
		methodAttr.setDisplayName(methodLocale);
		methodAttr.setExecutable(true);
		methodAttr.setUserExecutable(true);

		serverAPI.addMethod(server, input, output, methodAttr, new MoldingMachine_OPCUA());

		Object example = "HELLO";
		serverAPI.setData(example);
		System.out.println(serverAPI.getData());

	}

	/**
	 * This method is called from the Main.java main method to init and start the
	 * opcua server/client.
	 */
	public static void startMolding() {

		// MoldingMachineController.mMController = new MoldingMachineController();

		// new SimpleThread().start();

		// mMController.closeMold();

	}

	/**
	 * main method for testing purposes. calling the constructor then running the
	 * server in a separate thread.
	 */
	public static void main(String[] args) {
		// mMachine_OPCUA = ;
		mMController = new MoldingMachineController();

		new Thread(new Runnable() {
			@Override
			public void run() {
				MoldingMachineController.mMController.serverAPI.runServer(MoldingMachineController.mMController.server);
			}
		}).start();

		mMController.closeMold();

	}

	/**
	 * Overriding the model abstract method injectMold in MoldingMachine super class
	 * to implement the logic needed
	 */
	@Override
	public void injectMold() {
		super.injectMold();
		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState());
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
			public void run() {
				fireTrigger(MoldingTrigger.OPENING);

			}
		}, 2, TimeUnit.SECONDS);

	}

	/**
	 * Overriding the model abstract method openMold in MoldingMachine super class
	 * to implement the logic needed
	 */
	@Override
	public void openMold() {
		super.openMold();

		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState());
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
			public void run() {
				fireTrigger(MoldingTrigger.ROBOT);

			}
		}, 2, TimeUnit.SECONDS);

	}

	/**
	 * Overriding the model abstract method closeMold in MoldingMachine super class
	 * to implement the logic needed
	 */
	@Override
	public void closeMold() {
		super.closeMold();
		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState());

		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
			public void run() {
				fireTrigger(MoldingTrigger.MOLDING);

			}
		}, 2, TimeUnit.SECONDS);

	}

	/**
	 * Overriding the model abstract method waitForRobot in MoldingMachine super
	 * class to implement the logic needed
	 */
	@Override
	public void waitForRobot() {
		super.waitForRobot();
		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState()); // fireTrigger(MoldingTrigger.CLOSING);

	}

}
