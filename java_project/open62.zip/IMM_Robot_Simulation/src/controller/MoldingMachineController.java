package controller;

import open62Wrap.*;

import java.util.Date;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import molding.MoldingMachine;
import molding.MoldingTrigger;

class SimpleThread extends Thread {


	public SimpleThread() {
		super("OPCUA");


	}

	public void run() {
		MoldingMachineController.mMController.serverAPI = new ServerAPIBase();
		MoldingMachineController.mMController.server = MoldingMachineController.mMController.serverAPI.createServer(4840, "localhost");
		MoldingMachineController.mMController.statusNodeID = MoldingMachineController.mMController.serverAPI.manuallyDefineIMM(MoldingMachineController.mMController.server);
		MoldingMachineController.mMController.serverAPI.addMonitoredItem(MoldingMachineController.mMachine_OPCUA, MoldingMachineController.mMController.server, MoldingMachineController.mMController.statusNodeID);
		MoldingMachineController.mMController.serverAPI.runServer(MoldingMachineController.mMController.server);
	}
}

public class MoldingMachineController extends MoldingMachine {
	static {
		System.loadLibrary("opcua_java_api");
	}

	static  class MoldingMachine_OPCUA extends ServerAPIBase {
	
		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("iiiiii monitored_itemChanged::monitored_itemChanged() invoked." + value);
			if(value == MoldingTrigger.CLOSING.ordinal()) {
				System.out.println("The Robot is OUT lets close for the new mold");
				mMController.closeMold();
			}
		}

	}

	ServerAPIBase serverAPI;
	SWIGTYPE_p_UA_Server server;
	UA_NodeId statusNodeID;
	static MoldingMachineController mMController;
	static MoldingMachine_OPCUA mMachine_OPCUA;

	public MoldingMachineController() {
		System.out.println("Start");
		

	}
	
	public static void startMolding() {
	
			MoldingMachineController.mMController = new MoldingMachineController();
			
			new SimpleThread().start();

		
			mMController.closeMold();
		
	}

	public static void main(String[] args) {

		MoldingMachineController.mMController = new MoldingMachineController();
		MoldingMachineController.mMachine_OPCUA = new MoldingMachine_OPCUA();
		new SimpleThread().start();

		//mMController.closeMold();

	}

	@Override
	public void injectMold() {
		super.injectMold();
		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState());

		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
		          public void run() {
		        		fireTrigger(MoldingTrigger.OPENING);

		          }
		     }, 2, TimeUnit.SECONDS);
	
	}

	@Override
	public void openMold() {
		super.openMold();
		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState());
	
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
		          public void run() {
		        	  fireTrigger(MoldingTrigger.ROBOT);

		          }
		     }, 2, TimeUnit.SECONDS);
		
		

	}

	@Override
	public void closeMold() {
		super.closeMold();
		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState());
		
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
		          public void run() {
		        	  fireTrigger(MoldingTrigger.MOLDING);

		          }
		     }, 2, TimeUnit.SECONDS);
		
		

	}

	@Override
	public void waitForRobot() {
		super.waitForRobot();
		serverAPI.writeVariable(server, statusNodeID, mMController.getCurrentState());
		//fireTrigger(MoldingTrigger.CLOSING);

	}
	
}
