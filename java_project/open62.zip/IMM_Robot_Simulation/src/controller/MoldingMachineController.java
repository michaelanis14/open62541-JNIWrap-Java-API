package controller;

import open62Wrap.*;
import molding.MoldingMachine;
import molding.MoldingTrigger;

class SimpleThread extends Thread {
	ServerAPIBase serverAPI;
	SWIGTYPE_p_UA_Server server;

	public SimpleThread(ServerAPIBase serverAPI, SWIGTYPE_p_UA_Server server) {
		super("OPCUA");

		this.serverAPI = serverAPI;
		this.server = server;

	}

	public void run() {

		serverAPI.runServer(server);
	}
}

public class MoldingMachineController extends MoldingMachine {
	static {
		System.loadLibrary("opcua_java_api");
	}

	class MoldingMachine_OPCUA extends ServerAPIBase {

		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("iiiiii monitored_itemChanged::monitored_itemChanged() invoked." + value);
			// fireTrigger(MoldingTrigger.OPENING);
		}

	}

	ServerAPIBase serverAPI;
	SWIGTYPE_p_UA_Server server;
	UA_NodeId statusNodeID;
	static MoldingMachineController mMController;

	public MoldingMachineController() {
		System.out.println("Start");
		serverAPI = new ServerAPIBase();
		server = serverAPI.createServerDefaultConfig();
		statusNodeID = serverAPI.manuallyDefineIMM(server);
		serverAPI.addMonitoredItem(new MoldingMachine_OPCUA(), server, statusNodeID);

	}
	
	public static void startMolding() {
	
			MoldingMachineController.mMController = new MoldingMachineController();
			new SimpleThread(mMController.serverAPI, mMController.server).start();

			mMController.closeMold();

		
	}

	public static void main(String[] args) {

		MoldingMachineController.mMController = new MoldingMachineController();
		new SimpleThread(mMController.serverAPI, mMController.server).start();

		mMController.closeMold();

	}

	@Override
	public void injectMold() {
		super.injectMold();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("Injecting Mold");
			Thread.sleep((int) (Math.random() * 1000));
			System.out.println("Injected the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		fireTrigger(MoldingTrigger.OPENING);

	}

	@Override
	public void openMold() {
		super.openMold();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("Opening Mold");
			Thread.sleep((int) (Math.random() * 1000));
			System.out.println("Opened the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		fireTrigger(MoldingTrigger.ROBOT);

	}

	@Override
	public void closeMold() {
		super.closeMold();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("Closing Mold");
			Thread.sleep((int) (Math.random() * 1000));
			System.out.println("Closed the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(MoldingTrigger.MOLDING);

	}

	@Override
	public void waitForRobot() {
		super.waitForRobot();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("I am Waiting for Robot...");
			Thread.sleep((int) (Math.random() * 2000));
			System.out.println("I am Waiting for Robot...");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//fireTrigger(MoldingTrigger.CLOSING);

	}
	
}
