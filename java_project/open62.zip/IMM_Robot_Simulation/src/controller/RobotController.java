package controller;

import open62Wrap.*;
import roboticArm.RoboticArm;
import roboticArm.ArmTrigger;
import molding.MoldingTrigger;
import molding.MoldingTrigger.*;

public class RobotController extends RoboticArm {
	ServerAPIBase serverAPI;
	ClientAPIBase clientAPI;
	SWIGTYPE_p_UA_Server server;
	SWIGTYPE_p_UA_Client client;
	UA_NodeId statusNodeID;
	Robot_OPCUA_Client client_opcua;
	static RobotController robotController;

	static {
		System.loadLibrary("opcua_java_api");
	}

	class Robot_OPCUA_Client extends ClientAPIBase {

		int i = 0;

		@Override
		public void clientConnected(ClientAPIBase clientAPIBase, SWIGTYPE_p_UA_Client client, String serverUrl) {
			System.out.println("Connected" );
	
		
			if (i < 1) {

				statusNodeID = ClientAPIBase.getNodeByName(client, "Status");
				ClientAPIBase.clientSubtoNode(clientAPIBase, client, statusNodeID);
				System.out.println("THE READ VALUE:" + ClientAPIBase.clientReadValue(client, statusNodeID));
				// ClientAPIBase.clientWriteValue(client, statusId, 991);

				i++;
				if (ClientAPIBase.clientReadValue(client, statusNodeID) == MoldingTrigger.ROBOT.ordinal()) {
					moveIn();
				}
			}

		}

		@Override
		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("IMM FROM CLIENT Status monitored_itemChanged() invoked." + value);
			if (value == 3) {
				moveIn();
			}

		}

	}

	class Robot_OPCUA extends ServerAPIBase {

		@Override
		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("Robot Status monitored_itemChanged() invoked." + value);

		}
	}

	public RobotController() {
		System.out.println("Start");
		serverAPI = new ServerAPIBase();
		server = serverAPI.createServer(4050, "localhost");
		statusNodeID = serverAPI.manuallyDefineRobot(server);
		serverAPI.addMonitoredItem(new Robot_OPCUA(), server, statusNodeID);

		clientAPI = new ClientAPIBase();
		client = ClientAPIBase.initClient();
		client_opcua = new Robot_OPCUA_Client();

	}

	public static void startRobot() {
		// RobotController.robotController = new RobotController();
		// new RobotSimpleThread(robotController.serverAPI,
		// robotController.server).start();
		// new RobotClientThread(robotController.clientAPI,
		// robotController.client).start();

		// robotController.ready();
	}

	public static void main(String[] args) {

		RobotController.robotController = new RobotController();
		// new RobotSimpleThread(robotController.serverAPI,
		// robotController.server).start();

		new Thread(new Runnable() {
			@Override
			public void run() {
				robotController.serverAPI.runServer(robotController.server);
			}
		}).start();

		new Thread(new Runnable() {
			@Override
			public void run() {
				ClientAPIBase.clientConnect(robotController.client_opcua, robotController.client,
						"opc.tcp://localhost:4840");
			}
		}).start();
		// UA_NodeId statusId =
		// ClientAPIBase.getNodeByName(robotController.client,"Status");

		// ClientAPIBase.clientSubtoNode(new Robot_OPCUA_Client()
		// ,robotController.client, statusId);

		// System.out.println("THE READ VALUE:" +
		// ClientAPIBase.clientReadValue(robotController.client, statusId));

		// ClientAPIBase.clientWriteValue(robotController.client, statusId,990);

		robotController.ready();

	}

	@Override
	public void moveIn() {
		super.moveIn();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			Thread.sleep((int) (Math.random() * 6000));
			System.out.println("Moved in the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(ArmTrigger.GRAB);
	}

	@Override
	public void moveOut() {
		super.moveOut();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			Thread.sleep((int) (Math.random() * 6000));
			System.out.println("Moved out the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	ClientAPIBase.clientWriteValue(client, statusNodeID, 1);
		fireTrigger(ArmTrigger.RELEASE);
	}

	@Override
	public void grab() {
		super.grab();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			Thread.sleep((int) (Math.random() * 6000));
			System.out.println("Grabed in the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(ArmTrigger.MOVE_OUT);
	}

	@Override
	public void release() {
		super.release();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			Thread.sleep((int) (Math.random() * 6000));
			System.out.println("Released in the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(ArmTrigger.READY);

	}

	@Override
	public void ready() {
		super.ready();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		System.out.println("Ready in Mold");

		// fireTrigger(ArmTrigger.GRAB);
	}

}
