package controller;

import open62Wrap.*;
import roboticArm.RoboticArm;
import roboticArm.ArmTrigger;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import molding.MoldingTrigger;

/**
 * This is the controller class for the RoboticArm where the logic shall be
 * implemented also the OPCUA client/server implementations. The class extends
 * the the RoboticArm model class, to implement the logic at each abstract state
 * in the model also wire up the connections between states as the logic drives.
 * 
 * @author Michael Bishara
 */

public class RobotController extends RoboticArm {
	ServerAPIBase serverAPI;
	ClientAPIBase clientAPI;
	SWIGTYPE_p_UA_Server server;
	SWIGTYPE_p_UA_Client client;
	UA_NodeId statusNodeID;
	Robot_OPCUA_Client client_opcua;
	static RobotController robotController;

	/**
	 * static initializing for the opcua java wrapper
	 */
	static {
		System.loadLibrary("opcua_java_api");
	}

	/**
	 * Extending for the Client API Base to implement the callback methods form the
	 * c libraries , enabling callback s from the c library to the java code.
	 */
	class Robot_OPCUA_Client extends ClientAPIBase {

		int i = 0; // calls counter

		/**
		 * Receiving interval calls from the c library when the client is connected
		 * successfully to a server. This helps to set the monitored items at the
		 * connected server after connection is successfully made. The interval is set
		 * with this function call the c library UA_Client_run_iterate(client, 5000);
		 */
		@Override
		public void client_connected(ClientAPIBase clientAPIBase, SWIGTYPE_p_UA_Client client, String serverUrl) {
			System.out.println("Connected");

			if (i < 1) {
				i++;
				statusNodeID = ClientAPIBase.getNodeByName(client, "Status"); // get Node id at the server by name
				ClientAPIBase.clientSubtoNode(clientAPIBase, client, statusNodeID); // subscribe to changes at the
																					// server by id
				System.out.println("THE READ VALUE:" + ClientAPIBase.clientReadValue(client, statusNodeID)); // read the
																												// value
																												// for
																												// the
																												// node
																												// at
																												// the
																												// server
																												// by id
				// ClientAPIBase.clientWriteValue(client, statusId, 991);

				if (ClientAPIBase.clientReadValue(client, statusNodeID) == MoldingTrigger.ROBOT.ordinal()) { // *(For
																												// testing)*
																												// if
																												// the
																												// node
																												// value
																												// is
																												// waiting
																												// for
																												// robot
																												// ->
																												// move
																												// in
					// moveIn();
				}
			}

		}

		/**
		 * Receiving calls from the c library on monitored item(s) changed. can be
		 * further filtered by Node id. As a first step considering the monitored item
		 * value is int, but later could be changed to more generic variant.
		 * 
		 * @param nodeId the node id triggered the change
		 * @param value  the value of the node triggered the change
		 */
		@Override
		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("IMM FROM CLIENT Status monitored_itemChanged() invoked." + value);
			if (value == 3) {
				moveIn();
			}

		}

	}

	/**
	 * Extending for the Server API Base to implement the callback methods form the
	 * c libraries , enabling callback s from the c library to the java code.
	 */

	class Robot_OPCUA extends ServerAPIBase {
		/**
		 * Extending for the Server API Base to implement the callback methods form the
		 * c libraries , enabling callback s from the c library to the java code.
		 * 
		 * @param nodeId the node id triggered the change
		 * @param value  the value of the node triggered the change
		 */
		@Override
		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("Robot Status monitored_itemChanged() invoked." + value);

		}
	}

	/**
	 * This the Robot controller constructor
	 */
	public RobotController() {
		System.out.println("Start");
		serverAPI = new ServerAPIBase();
		server = serverAPI.createServer(4050, "localhost");
		statusNodeID = serverAPI.manuallyDefineRobot(server);
		// serverAPI.addMonitoredItem(new Robot_OPCUA(), server, statusNodeID);

		clientAPI = new ClientAPIBase();
		client = ClientAPIBase.initClient();
		client_opcua = new Robot_OPCUA_Client();

	}

	/**
	 * This method is called from the Main.java main method to init and start the
	 * opcua server/client.
	 */
	public static void startRobot() {
		// RobotController.robotController = new RobotController();
		// new RobotSimpleThread(robotController.serverAPI,
		// robotController.server).start();
		// new RobotClientThread(robotController.clientAPI,
		// robotController.client).start();

		// robotController.ready();
	}

	/**
	 * main method for testing purposes. calling the constructor then running the
	 * server in a separate thread.
	 */
	public static void main(String[] args) {

		RobotController.robotController = new RobotController();

		new Thread(new Runnable() {
			@Override
			public void run() {
				robotController.serverAPI.runServer(robotController.server);
			}
		}).start();

		ClientAPIBase.clientConnect(robotController.client_opcua, robotController.client, "opc.tcp://localhost:4840");

	}

	/**
	 * Overriding the model abstract method moveIn in RoboticArm super class to
	 * implement the logic needed
	 */
	@Override
	public void moveIn() {
		super.moveIn();
		System.out.println("moveIn in Mold");

		serverAPI.writeVariable(server, statusNodeID,this.getCurrentState());
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
			public void run() {
				fireTrigger(ArmTrigger.GRAB);

			}
		}, 5, TimeUnit.SECONDS);

	}

	/**
	 * Overriding the model abstract method moveOut in RoboticArm super class to
	 * implement the logic needed
	 */
	@Override
	public void moveOut() {
		super.moveOut();
		System.out.println("moveOut  Mold");
		serverAPI.writeVariable(server, statusNodeID,this.getCurrentState());
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
			public void run() {
				fireTrigger(ArmTrigger.RELEASE);

			}
		}, 5, TimeUnit.SECONDS);
		// ClientAPIBase.clientWriteValue(client, statusNodeID, 1);

	}

	/**
	 * Overriding the model abstract method grab in RoboticArm super class to
	 * implement the logic needed
	 */
	@Override
	public void grab() {
		super.grab();
		System.out.println("grab in Mold");
		serverAPI.writeVariable(server, statusNodeID,this.getCurrentState());
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);
		exec.schedule(new Runnable() {
			public void run() {
				fireTrigger(ArmTrigger.MOVE_OUT);

			}
		}, 5, TimeUnit.SECONDS);

	}

	/**
	 * Overriding the model abstract method release in RoboticArm super class to
	 * implement the logic needed
	 */
	@Override
	public void release() {
		super.release();
		System.out.println("release out Mold");
		serverAPI.writeVariable(server, statusNodeID,this.getCurrentState());
		ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(1);

		exec.schedule(new Runnable() {
			public void run() {
				fireTrigger(ArmTrigger.READY);

			}
		}, 5, TimeUnit.SECONDS);

	}

	/**
	 * Overriding the model abstract method ready in RoboticArm super class to
	 * implement the logic needed
	 */
	@Override
	public void ready() {
		super.ready();
		System.out.println("Ready in Mold");
		serverAPI.writeVariable(server, statusNodeID,this.getCurrentState());
		ClientAPIBase.clientWriteValue(client, statusNodeID, 0);

		// fireTrigger(ArmTrigger.GRAB);
	}

}
