package controller;


import open62Wrap.*;
import roboticArm.RoboticArm;
import roboticArm.ArmTrigger;;

class RobotSimpleThread extends Thread {
	ServerAPIBase serverAPI;
	SWIGTYPE_p_UA_Server server;

	public RobotSimpleThread(ServerAPIBase serverAPI, SWIGTYPE_p_UA_Server server) {
		super("OPCUA");

		this.serverAPI = serverAPI;
		this.server = server;

	}

	public void run() {

		serverAPI.runServer(server);
	}
}



public class RobotController  extends RoboticArm{
	static {
		System.loadLibrary("opcua_java_api");
	}

	class Robot_OPCUA extends ServerAPIBase {

		@Override
		public void monitored_itemChanged(UA_NodeId nodeId, int value) {
			System.out.println("Robot Status monitored_itemChanged() invoked." + value);
			
		}

	}
String x;
	ServerAPIBase serverAPI;
	ClientAPIBase clientAPI;
	SWIGTYPE_p_UA_Server server;
	UA_NodeId statusNodeID;
	static RobotController robotController;
	
	

	public RobotController() {
		System.out.println("Start");
		serverAPI = new ServerAPIBase();
		server = serverAPI.createServer(4050, "localhost");
		statusNodeID = serverAPI.manuallyDefineRobot(server);
		serverAPI.addMonitoredItem(new Robot_OPCUA(), server, statusNodeID);
/*		
		clientAPI = new ClientAPIBase();
		SWIGTYPE_p_UA_Client client = clientAPI.initClient();
		clientAPI.clientConnect(client);
		UA_NodeId statusId = clientAPI.getStatusNode(client);
		
		clientAPI.clientSubtoNode(client, statusId);
		
		System.out.println(clientAPI.clientReadValue(client, statusId));
		clientAPI.clientWriteValue(client, statusId,990);
		//new SimpleThread(client,statusId).start();
	//	System.out.println(serverAPI.clientReadValue(client, statusId));
*/
	}
	
	public static void startRobot() {
		RobotController.robotController = new RobotController();
		new RobotSimpleThread(robotController.serverAPI, robotController.server).start();

		robotController.ready();
	}

	public static void main(String[] args) {

		RobotController.robotController = new RobotController();
		new RobotSimpleThread(robotController.serverAPI, robotController.server).start();

		robotController.ready();

	}
	
	@Override
	public void moveIn() {
		super.moveIn();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("Movinging in Mold");
			Thread.sleep((int) (Math.random() * 1000));
			System.out.println("Moved in the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(ArmTrigger.GRAB);
	}
	@Override
	public void moveOut() {
		super.moveOut();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("Movinging out Mold");
			Thread.sleep((int) (Math.random() * 1000));
			System.out.println("Moved out the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(ArmTrigger.RELEASE);
	}
	@Override
	public void grab() {
		super.grab();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("Grabing in Mold");
			Thread.sleep((int) (Math.random() * 1000));
			System.out.println("Grabed in the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(ArmTrigger.MOVE_OUT);
	}
	@Override
	public void release() {
		super.release();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		try {
			System.out.println("Releasing in Mold");
			Thread.sleep((int) (Math.random() * 1000));
			System.out.println("Released in the Mold");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fireTrigger(ArmTrigger.READY);

	}
	@Override
	public void ready() {
		super.ready();
		serverAPI.writeVariable(server, statusNodeID, this.getCurrentState());
		System.out.println("Ready in Mold");
		
		fireTrigger(ArmTrigger.GRAB);
	}


}
