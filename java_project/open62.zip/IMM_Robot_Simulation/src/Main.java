import controller.MoldingMachineController;
import controller.RobotController;

class RobotSimpleThread extends Thread {

	public RobotSimpleThread() {
		super("OPCUA");

	}

	public void run() {
		MoldingMachineController.startMolding();

	}
}

public class Main {
	public static void main(String[] args) {

		new RobotSimpleThread().start();
		RobotController.startRobot();

	}
}
