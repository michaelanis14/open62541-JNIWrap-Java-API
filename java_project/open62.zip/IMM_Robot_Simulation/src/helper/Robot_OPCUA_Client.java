package helper;

import open62Wrap.ClientAPIBase;
import open62Wrap.SWIGTYPE_p_UA_Client;
import open62Wrap.UA_NodeId;

public 	class Robot_OPCUA_Client extends ClientAPIBase {

	
	int i = 0;
	UA_NodeId statusId;
	
	@Override
	public void clientConnected(ClientAPIBase clientAPIBase,SWIGTYPE_p_UA_Client client,String serverUrl) {
		
		if( i < 1) {
			System.out.println("Connected");
		statusId = ClientAPIBase.getNodeByName(client,"Status");
		
			ClientAPIBase.clientSubtoNode(clientAPIBase ,client, statusId);
			
			System.out.println("THE READ VALUE:" + ClientAPIBase.clientReadValue(client, statusId));
			
			ClientAPIBase.clientWriteValue(client, statusId,991);
			i++;
		}
		else {
			ClientAPIBase.clientWriteValue(client, statusId,i);
			i++;
		}
		
	}
	
	
	@Override
	public void monitored_itemChanged(UA_NodeId nodeId, int value) {
		System.out.println("IMM FROM CLIENT Status monitored_itemChanged() invoked." + value);
		
	}


}

