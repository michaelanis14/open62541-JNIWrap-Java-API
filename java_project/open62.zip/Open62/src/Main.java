

class SimpleThread extends Thread {
	SWIGTYPE_p_UA_Server localServer;
	UA_NodeId immID;
    public SimpleThread(SWIGTYPE_p_UA_Server server,UA_NodeId immID) {
    	
        super("OPCUA");
        this.localServer = server;
        this.immID = immID;
    }
    public void run() {
        for(int i=4;i<5;i++) {
        	ServerAPIBase serverAPI = new ServerAPIBase();
        	serverAPI.writeVariable(this.localServer,this.immID,i);
            System.out.println(getName());
            try {
                sleep((int)(Math.random() * 1000));
            } catch (InterruptedException e) {}
        }
        //System.out.println("DONE! ");
    }
}


public class Main extends ServerAPIBase {
	static {
	    System.loadLibrary("opcua_java_api");
	  }
	
	  public Main() {
		  super();
	  }
	
	public static void main(String args[]) {
		
		
		System.out.println("Start");
		ServerAPIBase serverAPI = new ServerAPIBase();
		SWIGTYPE_p_UA_Server server = serverAPI.createServerDefaultConfig();
		UA_NodeId immID= serverAPI.manuallyDefineIMM(server);
		//	open62541.addImmObjectInstance(server,"IMM11");
		//open62541.addImmObjectInstance(server,"IMM22");
		// System.out.println(immID);
		//open62541.addPumpTypeConstructor(server);
		//open62541.addImmObjectInstance(server,"IMM33");
		// open62541.writeVariable(server,immID,true);
		serverAPI.addMonitoredItemToCurrentTimeVariable(new Main(),server,immID);
		serverAPI.writeVariable(server,immID,55);
		// open62541.writeVariable(server,immID,true);
		//open62541.addImmObjectInstance(server,"IMM4");
		//

		
		//serverAPI.callup(new Main());
		 
		// new SimpleThread(server,immID).start();
		server = serverAPI.runServer(server);
		
		


	}

	  public void monitored_itemChanged(UA_NodeId nodeId, UA_DataValue value) {
	    System.out.println("iiiiii monitored_itemChanged::monitored_itemChanged() invoked."+nodeId.toString() + value.toString());
	  }
	
	
}

